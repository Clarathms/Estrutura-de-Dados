package com.company;

public class Q1 {
    /*

    D) 2, 7, 3, 8, 4, 5

A sequ�ncia se encontra errada, dado o 8 filho do 3 e n�o filha do 7 � direita .

Sequencia correta:
      [(2)
          [7]]
   [[[3        8]
        4]
           5]

     */

}
