package com.company;

public class Main {

    public static void main(String[] args) {

      //  Q1.main();

      //  Q2.main();

      //  Q3.main();

      //  Q4.main();
      //  Q5.main();

        Q6.main();


    }
}
