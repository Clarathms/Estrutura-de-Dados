package com.company;

public class Main {

    public static void main(String[] args) {

        System.out.println("\nQUESTÃO 1:");
        Q1.main();
        System.out.println("***************************");
        System.out.println("\nQUESTÃO 2:");
        Q2.main();
        System.out.println("***************************");
        System.out.println("\nQUESTÃO 3:");
        Q3.main();
        System.out.println("***************************");
        System.out.println("\nQUESTÃO 4:");
        Q4.main();
        System.out.println("***************************");
        System.out.println("\nQUESTÃO 5:");
        Q5.main();
        System.out.println("***************************");
        System.out.println("\nQUESTÃO 6:");
        Q6.main();

    }
}
