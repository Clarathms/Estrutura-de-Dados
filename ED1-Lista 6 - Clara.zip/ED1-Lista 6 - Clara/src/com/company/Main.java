package com.company;

public class Main {

    public static void main(String[] args) {

        // QUESTÃO 1
        //Q1.main();

        // QUESTAO 2
        //Q2.main();

        //QUESTAO 3
        //Q3.main();

        //QUESTAO 4
       // Q4.main();

       // Q5.main();

        Q6.main();

    }
}
